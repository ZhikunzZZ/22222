import java.util.LinkedList;

public class Vertex {

    private LinkedList<Node> adjList ;
    private int index;
    private boolean visited;
    private int pre;
    private int counter = 0;

    public Vertex(int n) {
        adjList = new LinkedList<Node>();
        index = n;
        visited = false;
        pre = index;
    }
    public void setCounter(int c){
        counter = c;
    }
    public int getCounter(){
        return counter;
    }
    public boolean getVisited(){
        return visited;
    }
    public void setVisited(boolean b){
        visited = b;
    }
    public int getPre(){
        return pre;
    }
    public void setPre(int p){
        pre = p;
    }
    
    public int getIndex(){
    	return index;
    }
    
    public void setIndex(int n){
    	index = n;
    }

    public void addToAdjList(int n){
        adjList.addLast(new Node(n));
    }

    public int vertexDegree(){
        return adjList.size();
    }

    public LinkedList<Node> getAdjList(){
        return adjList;
    }
}


