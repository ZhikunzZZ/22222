import java.io.*;
import java.util.*;

/**
 program to find word ladder with shortest path (i.e. minimum number edges
 */
public class Main {

	public static void main(String[] args) throws IOException {

		long start = System.currentTimeMillis();

		String inputFileName = args[0]; // dictionary
		String word1 = args[1]; // first word
		String word2 = args[2]; // second word
  
		FileReader reader = new FileReader(inputFileName);
		Scanner in = new Scanner(reader);
		
		// read in the data here

		List<String> words = new ArrayList<>();
		while(in.hasNextLine()){
			String line = in.nextLine();
			if(line != ""){
				words.add(line);
			}
		}

		// create graph here

		Graph adj_list = new Graph(words.size());
		for(int i = 0; i < words.size(); i++) {
			for(int j = 0; j < words.size(); j++) {
				if(i != j) {
					char[] first = words.get(i).toCharArray();
					char[] second = words.get(j).toCharArray();
					int counter = 0;
					for(int x = 0; x < 5; x++) {
						if(first[x] != second[x]) {
							counter += 1;
						}
					}
					if(counter == 1) {
						adj_list.getVertex(i).addToAdjList(j);
					}
				}
			}
		}

		reader.close();

		// do the work here

		adj_list.short_path(words.indexOf(word1),words.indexOf(word2));
		Vertex second_word = adj_list.getVertices()[words.indexOf(word2)];
		System.out.println("word1 = "+ word1);
		System.out.println("word2 = "+ word2);
		List<String> outputs = new ArrayList<>();
		if(second_word.getCounter() == 0){
			System.out.println("no word ladder exists");
		}else{
			System.out.println("shortest word ladder of length " + second_word.getCounter());
			System.out.println("example shortest word ladder:");
			Vertex cur = second_word;
			int cur_counter = cur.getCounter();

			for(int i = 0; i < cur_counter; i++){
				outputs.add(0,words.get(cur.getIndex()));
				cur = adj_list.getVertices()[cur.getPre()];
			}
			System.out.println("    "+word1);
			for(String s:outputs){
				System.out.println("    "+s);
			}
		}

		// end timer and print total time
		
		long end = System.currentTimeMillis();
		System.out.println("\nElapsed time: " + (end - start) + " milliseconds");
	}

}
