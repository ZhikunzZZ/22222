import java.util.ArrayList;
import java.util.List;

public class Graph {
    private Vertex[] vertices;
    private int numVertices = 0;
    
    public Graph(int n) {
		numVertices = n;
		vertices = new Vertex[n];
		for (int i = 0; i < n; i++)
			vertices[i] = new Vertex(i);
	}

    public int size() {
		return numVertices;
	}

	public Vertex getVertex(int i) {
		return vertices[i];
	}

    public void setVertex(int i) {
		vertices[i] = new Vertex(i);
	}

    public Vertex[] getVertices() {
		return vertices;
	}
    public void short_path(int word1,int word2){
        Vertex start = vertices[word1];
        List<Vertex> wait_list = new ArrayList<>();
        wait_list.add(start);
        while(!wait_list.isEmpty()){
            Vertex cur = wait_list.get(0);
            wait_list.remove(cur);
            if(cur == vertices[word2]){
                break;
            }
            for(Node n:cur.getAdjList()){
                Vertex node = vertices[n.getVertexIndex()];
                if(!node.getVisited()){
                    node.setVisited(true);
                    node.setPre(cur.getIndex());
                    node.setCounter(cur.getCounter()+1);
                    wait_list.add(node);
                }
            }
        }
    }
}
