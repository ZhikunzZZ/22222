public class Node {
    private int vertexIndex;

    public Node(int n){
        vertexIndex = n;
    }

    public int getVertexIndex(){
        return vertexIndex;
    }


    public void setVertexIndex(int n){
        vertexIndex = n;
    }

}
