public class Node2{
    private int vertexIndex;
    private int weight;

    public Node2(int n){
        vertexIndex = n;
    }

    public int getVertexIndex(){
        return vertexIndex;
    }


    public void setVertexIndex(int n){
        vertexIndex = n;
    }

    public int getWeight(){
        return weight;
    }

    public void setWeight(int w){
        weight = w;
    }

}
