import java.util.ArrayList;
import java.util.List;

public class Graph2 {
    private Vertex2[] vertices;
    private int numVertices = 0;
    
    public Graph2(int n) {
		numVertices = n;
		vertices = new Vertex2[n];
		for (int i = 0; i < n; i++)
			vertices[i] = new Vertex2(i);
	}

    public int size() {
		return numVertices;
	}

	public Vertex2 getVertex(int i) {
		return vertices[i];
	}

    public void setVertex(int i) {
		vertices[i] = new Vertex2(i);
	}

    public Vertex2[] getVertices() {
		return vertices;
	}

    public List<Integer> dijkstra(int word1, int word2){
        Vertex2 start = vertices[word1];
        List<Integer> shortest = new ArrayList<>();
        for(int i = 0;i < vertices.length; i++){
            shortest.add(Integer.MAX_VALUE);
        }
        shortest.set(start.getIndex(),0);
        List<Node2> wait_list = new ArrayList<>();
        for(Node2 n: start.getAdjList()){
            wait_list.add(n);
            shortest.set(n.getVertexIndex(),n.getWeight());
            vertices[n.getVertexIndex()].setPre(start.getIndex());
        }
        start.setVisited(true);
        while(!wait_list.isEmpty()){
            int min = Integer.MAX_VALUE;
            Node2 min_node = null;
            for(Node2 n: wait_list){ 
                if(shortest.get(n.getVertexIndex()) < min){
                    min = shortest.get(n.getVertexIndex());
                    min_node = n;
                }
            }
            vertices[min_node.getVertexIndex()].setVisited(true);
            wait_list.remove(min_node);
            for(Node2 n: vertices[min_node.getVertexIndex()].getAdjList()){
                int new_wt = shortest.get(min_node.getVertexIndex()) + n.getWeight();
                if(new_wt < shortest.get(n.getVertexIndex())){
                        shortest.set(n.getVertexIndex(),new_wt);
                        vertices[n.getVertexIndex()].setPre(vertices[min_node.getVertexIndex()].getIndex());
                }
                if(n.getVertexIndex() == word2){
                    vertices[n.getVertexIndex()].setVisited(true);
                    break;
                }
                if(vertices[n.getVertexIndex()].getVisited() == false){
                    Boolean b = false;
                    for(Node2 all_n: wait_list){
                        if(all_n.getVertexIndex() == n.getVertexIndex()){
                            b = true;
                        }
                    }
                    if(b == false){
                        wait_list.add(n);
                    }
                }
            }
        }
        return shortest;
    }
}
